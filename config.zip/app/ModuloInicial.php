<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModuloInicial extends Model
{
	protected $table = 'modulo_inicial';

	public function users()
	{
		
	}  
}
