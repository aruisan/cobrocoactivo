<?php
namespace App\Traits;

use App\FrontendImagen;
use Image;

Class ImagenTraits
{
	protected $newDateFormat = 'd.m.Y H:i';
}